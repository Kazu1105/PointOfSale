package tests

import org.scalatest.FunSuite
import store.model.checkout.SelfCheckout
import store.model.items.Item

class Task1 extends FunSuite {

  test("your test name") {
    var testSelfCheckout: SelfCheckout = new SelfCheckout()
    var testItem: Item = new Item("test item", 100.0)
    testSelfCheckout.addItemToStore("123", testItem)
  }

  test("your test description") {

    val testItem: Item = new Item("test item", 100.0)
    assert(testItem.description() == "test item")

  }

  test("your test number") {
    var testSelfCheckout: SelfCheckout = new SelfCheckout()
    assert(testSelfCheckout.displayString() == "")
    testSelfCheckout.numberPressed(4)
    assert(testSelfCheckout.displayString() == "4")
    testSelfCheckout.numberPressed(7)
    assert(testSelfCheckout.displayString() == "47")
    testSelfCheckout.numberPressed(2)
    assert(testSelfCheckout.displayString() == "472")

  }


  test("buy item") {
    val checkout: SelfCheckout = new SelfCheckout()
    val testItem: Item = new Item("test item", 100.0)
    checkout.addItemToStore("472", testItem)
    checkout.numberPressed(4)
    checkout.numberPressed(7)
    checkout.numberPressed(2)
    checkout.enterPressed()
    val cart: List[Item]=checkout.itemsInCart()
    assert(cart.size == 1)
    assert(cart.head.description()=="test item")
    assert(Math.abs(cart.head.price()-100.0)<0.001)
    //assert(checkout.displayString() == cart)
  }


}
