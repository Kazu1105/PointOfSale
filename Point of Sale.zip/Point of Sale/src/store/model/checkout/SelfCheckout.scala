package store.model.checkout
import store.model.items.Item
import store.view.SelfCheckoutGUI._

class SelfCheckout {
  var pressed:String=""
  var subtotal1:Double=0.0
  var tax1:Double=0.0
  var total1:Double=0.0
  var storage:Map[String,Item]=Map()
  //storage is the barcode -> item
  var cart:List[Item]=List()

  //var item:String=""
  var errorobj:Item= new Item("Error", 0.0)

  def addItemToStore(barcode: String, item: Item): Unit = {
    storage += (barcode->item)
    // This method adds an item to your store's checkout system. It does not add an item to the customer's cart
    // TODO
    storage
  }
  def numberPressed(number: Int): Unit = {
    pressed=pressed+number.toString
    println(pressed)

    // TODO
  }

  def clearPressed(): Unit = {
    pressed=""

    // TODO
  }

  def enterPressed(): Unit = {
    //appends the values in the storage into item while returning error if the barcode does not match an item
    //storage is the item
    cart= cart:+storage.getOrElse(pressed,errorobj)
    pressed=""
    /*
    for (i <- item){
    } */
    // TODO
  }

  def checkoutPressed(): Unit = {
    // TODO
  }

  def cashPressed(): Unit = {
    // TODO
  }

  def creditPressed(): Unit = {
    // TODO
  }

  def loyaltyCardPressed(): Unit = {
    // TODO
  }

  def displayString(): String = {
    pressed
    // TODO
  }

  def itemsInCart(): List[Item] = {
    cart
    //add 0.0 if barcode is not on list
  }
  def subtotal(): Double = {

    0.0
  }

  def tax(): Double = {
    0.0
  }

  def total(): Double = {
    total1=subtotal1+tax1
    total1
  }






  def prepareStore(): Unit = {
    // Similar to openMap in the Pale Blue Dot assignment, this method is not required and is
    // meant to help you run manual tests.
    //
    // This method is called by the GUI during setup. Use this method to prepare your
    // items and call addItemToStore to add their barcodes. Also add any sales/tax/etc to your
    // items.
    //
    // This method will not be called during testing and you should not call it in your tests.
    // Each test must setup its own items to ensure compatibility in AutoLab. However, you can
    // write a similar method in your Test Suite classes.

    // Example usage:
    //val testItem: Item = new Item("test item", 100.0)
    //this.addItemToStore("472", testItem)
  }

}
